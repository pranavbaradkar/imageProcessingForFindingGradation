all the csv contain total passing of mass
37.5 passing
26.5 passing
19 passing
13.2 passing
4.75 passing 
2.36 passing
0.3 passing
0.075 passing